
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import './App.css';
import Chatbot from './Chatbot';
import Ticket from './Ticket';


function App() {
  return (
    <BrowserRouter >
    <Routes>
      <Route path='/chatbot' element={<Chatbot />} />
      <Route path='/ticket' element={<Ticket />} />
      
    </Routes>

  
  </BrowserRouter>
  );
}

export default App;
