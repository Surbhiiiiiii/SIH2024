import React, { useEffect, useRef } from 'react';
import { useLocation } from 'react-router-dom';
import {QRCodeSVG} from 'qrcode.react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import './TicketPage.css'; // Import custom CSS for styling

function Ticket() {
    const location = useLocation();
    const qrRef = useRef();
   console.log(location.state);
   
    const { order_id, payment_id, name, email, contact, 
        preferredDate, visitTime, numberOfTickets, amount } = location.state ;

    useEffect(() => {

        const downloadTicketPdf = () => {
            const input = document.getElementById('ticket-content');
            if (input) {
                html2canvas(input).then((canvas) => {
                    const imgData = canvas.toDataURL('image/png');
                    const pdf = new jsPDF({
                        orientation: 'portrait',
                        unit: 'px',
                        format: [canvas.width, canvas.height],
                    });
                    pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
                    pdf.save(`Ticket_${name}.pdf`);
                });
            }
        };

        downloadTicketPdf(); // Automatically trigger download when the component mounts
    }, [name ]);


    if (!order_id) {
        return <div>Invalid Access</div>;
    }

    const qrData = `OrderID: ${order_id}, PaymentID: ${payment_id}, Name: ${name}, TicketCount: ${numberOfTickets}`;

    
   

   

    return (
        <div className="ticket-container" id="ticket-content">
            <div className="ticket">
                <div className="ticket-header">
                    <h1>Welcome to the Museum</h1>
                    <p>Your E-Ticket</p>
                </div>
                <div className="ticket-body">
                    <div className="ticket-details">
                        <p><strong>Name:</strong> {name}</p>
                        <p><strong>Email:</strong> {email}</p>
                        <p><strong>Contact:</strong> {contact}</p>
                        <p><strong>Number of Tickets:</strong> {numberOfTickets}</p>
                        <p><strong>Date of Visit:</strong> {preferredDate}</p>
                        <p><strong>Time of Visit:</strong> {visitTime}</p>
                        <p><strong>Total Amount:</strong> ₹{amount / 100}</p>
                        <p><strong>Order ID:</strong> {order_id}</p>
                        <p><strong>Payment ID:</strong> {payment_id}</p>
                    </div>
                    <div className="ticket-qr">
                        <QRCodeSVG
                            value={qrData}
                            size={150}
                            level={"H"}
                            includeMargin={true}
                            ref={qrRef}
                        />
                    </div>
                </div>
                <div className="ticket-footer">
                    <p>Thank you for your purchase!</p>
                    <p>Please bring this ticket to the entrance.</p>
                </div>
            </div>
        </div>
    );
}

export default Ticket;
